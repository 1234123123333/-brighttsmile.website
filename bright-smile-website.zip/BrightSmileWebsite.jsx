export default function BrightSmileWebsite() {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100 py-20 px-4 text-center">
        <h1 className="text-5xl font-extrabold tracking-wide text-gray-900 mb-4">Bright Smile Tooth Whitening Kit</h1>
        <p className="text-2xl font-medium italic text-gray-800 tracking-wider">
          A brighter smile starts with Bright Smile.
        </p>
      </section>
...
    </div>
  );
}